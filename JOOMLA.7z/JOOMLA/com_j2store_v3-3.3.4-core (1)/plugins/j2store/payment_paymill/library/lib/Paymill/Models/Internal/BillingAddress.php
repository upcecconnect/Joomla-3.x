<?php

namespace Paymill\Models\Internal;

/**
 * Model BillingAddress
 */
class BillingAddress extends AbstractAddress
{

}
